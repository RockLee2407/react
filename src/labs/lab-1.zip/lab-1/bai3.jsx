import styles from './bai3.module.css'

function bai3()  {
  return (
    <div>
        <h1 className={styles.title}>Chào mừng đến với Lab Styling</h1>
        <p className={styles.description}>
            Sử dụng CSS Module để tạo kiểu dáng riêng biệt cho từng component.
        </p>
    </div>
  )
}

export default bai3;