import { Container } from "react-bootstrap";

function Footer() {
    return(
        <Container fluid className="bg-primary text-dark text-center py-3 fw-bold">
            <p>Created by Luu Anh Tuan</p>
        </Container>
    )
}

export default Footer