import Header from "./Header";

import Footer from "./Footer";

function Bai3_Lab2() {
    return(
        <div>
            <Header></Header>
            <Footer></Footer>
        </div>
    )
}

export default Bai3_Lab2