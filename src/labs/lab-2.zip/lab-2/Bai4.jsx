import Card from "./Card";

function Bai4_lab2() {
    return(
        <div>
            <Card title="Card 1" content="Noi dung 1"/>
            <Card title="Card 2" content="Noi dung 2"/>
            <Card title="Card 3" content="Noi dung 3">
                <p>Noi dung con 3</p>
            </Card>
        </div>
    )
}

export default Bai4_lab2